<!DOCTYPE html>
<html>

<?php 
require('connection.php');
?>

<?php
//Stores username entered on previous page
$pnum     = $_POST['username'];
$password = $_POST['password'];

if ($pnum == "" OR $password == ""){
    echo "Invalid username and/or password"."<br>";
}
else{
	// Removes dashes from phone number
	$pnum = (string) $pnum;
	$pnum = str_replace("-", "", $pnum);

	//Sets SQL query to select password for given username
	$sql = "select password from employee where dept_name = 'Housekeeping' and phone_num = $pnum;";

	//Runs SQL query
	$result = mysqli_query($conn, $sql);

	//Stores password returned from query
	$row = mysqli_fetch_assoc($result);

	if (!isset($row['password'])){
		echo "Invalid username and/or password"."<br>";
	}
	else if ($password != $row['password']){
		echo "Invalid username and/or password"."<br>";
	}
	else{
		header('Location: housekeepingtable.php');
	}
}
mysqli_close($conn);
?>

<a class="button" href="housekeeping.html">Return to housekeeping login page</a>

</html>