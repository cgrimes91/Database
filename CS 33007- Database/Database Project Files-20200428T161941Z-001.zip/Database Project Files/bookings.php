<!DOCTYPE html>
<html>

<?php 
require('connection.php');
?>

<a class="button" href="checkin.php">Check In Guest</a><br>
<a class="button" href="checkout.php">Check Out Guest</a><br>  
<a class="button" href="payment.php">Enter Guest Payment</a><br>
<a class="button" href="front.html">Return to login</a><br>

<h1>Please submit the form to view bookings</h1>
<p1>Note: It is required that 'Branch' and at least 1 other field are filled out. Filling out additional fields will narrow the search.</p1>
<br> <br>

<?php
//Runs query to output list of all branches
echo "Please choose from the following branches:"."<br>";
$sql = "select branch_name from branch";
$results = mysqli_query($conn, $sql);

if (mysqli_num_rows($results) > 0){
	while($row = mysqli_fetch_assoc($results)){
		echo $row["branch_name"]."<br>";
	}
}
else{
	echo "No branches";
}
echo "<br>";
?>


<form method = "post">
	Branch: <br>
	<input type = "text" name = "branch"> <br> <br>

	Check in date: <br>
	<input type = "date" name = "inDate"> <br> <br>

	Check out date: <br>
	<input type = "date" name = "outDate"> <br> <br>

	Guest phone number: <br>
	<input type = "tel"  name = "phone" placeholder = "123-456-7890" pattern = "[0-9]{3}-[0-9]{3}-[0-9]{4}"> <br> <br>

	<input type="submit"> <br> <br>
</form>


<?php

if(!isset($_POST['branch'])){
	die("");
}

$branch = $_POST['branch'];

if ($branch == ""){
    die("Please enter a branch");
}

$in_d  = $_POST['inDate' ];
$out_d = $_POST['outDate'];
$pnum  = $_POST['phone'  ];

// Removes dashes from in date
$in_d2 = (string) $in_d;
$in_d2 = str_replace("-", "", $in_d);

// Removes dashes from out date
$out_d2 = (string) $out_d;
$out_d2 = str_replace("-", "", $out_d);

// Removes dashes from phone number
$pnum2 = (string) $pnum;
$pnum2 = str_replace("-", "", $pnum);

$select = "select name, phone_num, branch_name, room_num, check_in_date, check_out_date, party_size, price_p_night, didCheck_in, didCheck_out, didPay, datediff (check_out_date, check_in_date) as num_nights, price_p_night * (datediff (check_out_date, check_in_date)) as total ";

if ($in_d == "" AND $out_d == "" AND $pnum == ""){
	die("Please fill out at least 1 field in addition to 'Branch'");
}
elseif (!($in_d == "") AND $out_d == "" AND $pnum == ""){
	$message = "The bookings at the $branch branch with check in date $in_d are:<br>";

	$sql = 	"$select
		from guests natural join bookings natural join rooms
		where branch_name = '$branch' AND check_in_date = $in_d2;";
}
elseif($in_d == "" AND !($out_d == "") AND $pnum == ""){
	$message = "The bookings at the $branch branch with check out date $out_d are:<br>";

	$sql = 	"$select
		from guests natural join bookings natural join rooms
		where branch_name = '$branch' AND check_out_date = $out_d2;";
}
elseif($in_d == "" AND $out_d == "" AND !($pnum == "")){
	$message = "The bookings for guest $pnum at the $branch branch are:<br>";

	$sql = 	"$select
		from guests natural join bookings natural join rooms
		where branch_name = '$branch' AND phone_num = $pnum2;";
}
elseif(!($in_d == "") AND !($out_d == "") AND $pnum == ""){
	$message = "The bookings at the $branch branch with check in date $in_d and check out date $out_d are:<br>";

	$sql = 	"$select
		from guests natural join bookings natural join rooms
		where branch_name = '$branch' AND check_in_date = $in_d2 AND check_out_date = $out_d2;";
}
elseif(!($in_d == "") AND $out_d == "" AND !($pnum == "")){
	$message = "The bookings for guest $pnum at the $branch branch with check in date $in_d are:<br>";

	$sql = 	"$select
		from guests natural join bookings natural join rooms
		where branch_name = '$branch' AND phone_num = $pnum2 AND check_in_date = $in_d2;";
}
elseif($in_d == "" AND !($out_d == "") AND !($pnum == "")){
	$message = "The bookings for guest $pnum at the $branch branch with check out date $out_d are:<br>";

	$sql = 	"$select
		from guests natural join bookings natural join rooms
		where branch_name = '$branch' AND phone_num = $pnum2 AND check_out_date = $out_d2;";
}
elseif(!($in_d == "") AND !($out_d == "") AND !($pnum == "")){
	$message = "The bookings for guest $pnum at the $branch branch with check in date $in_d and check out date $out_d are:<br>";

	$sql = 	"$select
		from guests natural join bookings natural join rooms
		where branch_name = '$branch' AND phone_num = $pnum2 AND check_in_date = $in_d2 AND check_out_date = $out_d2;";	
}
else{	
	die("Error");
}

$result = mysqli_query($conn, $sql);

echo "$message"."<br>"."<br>";


//Outputs result of the query
if (mysqli_num_rows($result) > 0) {
		echo '<table border>';
		echo '<thead><tr>';
		echo '<th>'."Name".'</th>'.'<th>'."Phone Number".'</th>'.'<th>'."Branch Name".'</th>'.'<th>'."Room Num".'</th>'.'<th>'."Check in Date".'</th>'.'<th>'."Check out Date".'</th>'.'<th>'."Price per night".'</th>'.'<th>'."Num Nights".'</th>'.'<th>'."Total Due".'</th>'.'<th>'."Party Size".'</th>'.'<th>'."Check in?".'</th>'.'<th>'."Check out?".'</th>'.'<th>'."Paid?".'</th>';
		echo '</tr></thead>';
		echo '<tbody>';

		while($row = mysqli_fetch_assoc($result)) {
			echo '<tr>';
			echo "<td>" . $row["name"             ]. "</td>";
			echo "<td>" . $row["phone_num"        ]. "</td>";
			echo "<td>" . $row["branch_name"      ]. "</td>";
			echo "<td>" . $row["room_num"         ]. "</td>";
			echo "<td>" . $row["check_in_date"    ]. "</td>";
			echo "<td>" . $row["check_out_date"   ]. "</td>";			
			echo "<td>" . "$".$row["price_p_night"]. "</td>";
			echo "<td>" . $row["num_nights"       ]. "</td>";
			echo "<td>" . "$".$row["total"        ]. "</td>";
			echo "<td>" . $row["party_size"       ]. "</td>";
			echo "<td>" . $row["didCheck_in"      ]. "</td>";
			echo "<td>" . $row["didCheck_out"     ]. "</td>";
			echo "<td>" . $row["didPay"           ]. "</td>";
			echo '</tr>';
		}
		
		echo '</tbody>';
		echo '</table>';				
} 
else {
    echo "No results";
}
mysqli_close($conn);
?>

</html>