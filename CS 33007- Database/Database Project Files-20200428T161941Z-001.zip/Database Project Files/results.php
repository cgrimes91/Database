<!DOCTYPE html>
<html>
<body>
<h1>Available Rooms: <?php echo $_POST["location"];?></h1>

<?php 
require('connection.php');
?>

<?php

$loca  = $_POST["location"];
$in_d  = $_POST["in_date" ];
$out_d = $_POST["out_date"];

if($in_d == "" OR $out_d == ""){
	echo "The date(s) you provided are invalid, please try again.<br>";
}
elseif(!($in_d < $out_d)){
	echo "The check out date must be after the check in date.  Please try again.<br>";
}
else{
	$in_d2  = $_POST["in_date"];
	$out_d2 = $_POST["out_date"];

	$in_d = (string) $in_d;
	$in_d = str_replace("-", "", $in_d);

	$out_d = (string) $out_d;
	$out_d = str_replace("-", "", $out_d);

	$sql = "select *
		from rooms
		where branch_name = '$loca'

		except

		select room_num, branch_name, floor, num_beds, sq_ft, price_p_night
		from rooms_available
		where 	branch_name = '$loca' AND
			(
			(check_in_date <= $in_d  AND $in_d  <  check_out_date) OR 
			(check_in_date <  $out_d AND $out_d <= check_out_date) OR
			(check_in_date >  $in_d  AND $out_d >  check_out_date)
			);";

	$result = mysqli_query($conn, $sql);

	//Outputs result of the query
	if (mysqli_num_rows($result) > 0) {
		echo "The rooms available in $loca from $in_d2 until $out_d2 are:"."<br>"."<br>";
		echo '<table border>';
		echo '<thead><tr>';
		echo '<th>'."Room Number".'</th>'.'<th>'."Branch Name".'</th>'.'<th>'."Floor".'</th>'.'<th>'."Num Beds".'</th>'.'<th>'."Square Feet".'</th>'.'<th>'."Price per night".'</th>';
		echo '</tr></thead>';
		echo '<tbody>';

		while($row = mysqli_fetch_assoc($result)) {
			echo '<tr>';
			echo "<td>" . $row["room_num"]. "</td>";
			echo "<td>" . $row["branch_name"]. "</td>";
			echo "<td>" . $row["floor"]. "</td>";
			echo "<td>" . $row["num_beds"]. "</td>";
			echo "<td>" . $row["sq_ft"]. "</td>";
			echo "<td>" . "$".$row["price_p_night"]. "</td>";
			echo '</tr>';
		}			
		echo '</tbody>';
		echo '</table>';				
	} 
	else {
   	echo "No rooms are available for the selected dates.";
	}
}
mysqli_close($conn);
?>

<br>

<p1>Return to Date Selection :</p1>
<a href="browse.php">Date Selection</a><br>

<br><br>
<p1>Returning User Booking:</p1>
<a href="returning_user_book.php">Returning Users</a><br>

<p1>New User Booking:</p1>
<a href="new_user_book.php">New Users</a>

</body>
</html>