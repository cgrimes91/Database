<!DOCTYPE html>
<html>

<?php 
require('connection.php');
?>

<a class="button" href="housekeeping.html">Return to housekeeping login</a> <br>
<a class="button" href="employee.html">Return to department selection</a> <br><br><br>

<h1>Please choose a branch and a day to view occupied rooms</h1>

<?php
//Runs query to output list of all branches
echo "Please choose from the following branches:"."<br>";
$sql = "select branch_name from branch";
$results = mysqli_query($conn, $sql);

if (mysqli_num_rows($results) > 0){
	while($row = mysqli_fetch_assoc($results)){
		echo $row["branch_name"]."<br>";
	}
}
else{
	echo "No branches";
}
echo "<br>";
?>

<form method = "post">
	Branch: <br>
	<input type="text" name="branch"> <br><br>
	Day: <br>
	<input type="date" name="date"  > <br><br>
  	<input type="submit"><br><br>
</form>

<?php

if(!isset($_POST['branch']) or !isset($_POST['date'])){
	die();
}

$branch = $_POST['branch'];
$date   = $_POST['date'  ];

if ($branch == "" OR $date == ""){
    echo "0 results"."<br>";
}
else{
	$message = "The rooms occupied at the $branch branch on the morning of $date are:";
	echo "$message"."<br>";

	//Converts date to a string with no dashes
	$date = (string) $date;
	$date = str_replace("-", "", $date);

	$sql = "select room_num from bookings where branch_name = '$branch' and check_in_date < $date and $date <= check_out_date order by room_num;";
	$result = mysqli_query($conn, $sql);

	//Outputs result of the query
	if (mysqli_num_rows($result) > 0) {
    		while($row = mysqli_fetch_assoc($result)) {
       		echo $row["room_num"]."<br>";
   		}
	}
	else {
    	echo "0 results";
	}
}
mysqli_close($conn);
?>

</html>