<!DOCTYPE html>
<html>
<body>

<h1>Please Specify When And Where You Would Like To Stay</h1>

<?php 
require('connection.php');
?>

<?php
//Runs query to output list of all branches
echo "Please choose from the following branches:"."<br>";
$sql = "select branch_name from branch";
$results = mysqli_query($conn, $sql);

if (mysqli_num_rows($results) > 0){
	while($row = mysqli_fetch_assoc($results)){
		echo $row["branch_name"]."<br>";
	}
}
else{
	echo "No branches";
}
echo "<br>";
mysqli_close($conn);
?>
    
<form action = "results.php" method = "post">
	Check in Date:   <input type  = "date" name = "in_date" > <br> 
	Check out Date:  <input type  = "date" name = "out_date"> <br>
	Location:         <input type = "text" name = "location"> <br>
	                  <input type = "submit">
</form> 


<br><br>
<p2>Return To Main Site:</p2>
<a href="index.html">Home</a><br>

</body>
</html>