<!DOCTYPE html>
<html>

<?php 
require('connection.php');
?>

<a class="button" href="financeoption.html">Return to option selection</a> <br>
<a class="button" href="finance.html">Return to finance login</a> <br>
<a class="button" href="employee.html">Return to department selection</a> <br><br><br>

<h1>Please select a check out date to view payments due on that date:</h1>
<form method = "post">
	Check Out Date: <br>
	<input type="date" name="date"> <br><br>
  	<input type="submit"><br><br>
</form>

<?php

if(!isset($_POST['date'])){
	die();
}

$date = $_POST['date'];

if ($date == ""){
    echo "0 results"."<br>";
}
else{
	$message = "The the payments due on $date are:";
	echo "$message"."<br>"."<br>";

	//Converts date to a string with no dashes
	$date = (string) $date;
	$date = str_replace("-", "", $date);

	$sql = "select * from guest_totals where check_out_date = '$date';";
	$result = mysqli_query($conn, $sql);

	//Outputs result of the query
	if (mysqli_num_rows($result) > 0) {
			echo '<table border>';
			echo '<thead><tr>';
			echo '<th>'."Name".'</th>'.'<th>'."Phone Number".'</th>'.'<th>'."Branch Name".'</th>'.'<th>'."Room Number".'</th>'.'<th>'."Check Out Date".'</th>'.'<th>'."Paid?".'</th>'.'<th>'."Total Due".'</th>';
			echo '</tr></thead>';
			echo '<tbody>';

			while($row = mysqli_fetch_assoc($result)) {
				echo '<tr>';
				echo "<td>" . $row["name"          ]. "</td>";
				echo "<td>" . $row["phone_num"     ]. "</td>";
				echo "<td>" . $row["branch_name"   ]. "</td>";
				echo "<td>" . $row["room_num"      ]. "</td>";
				echo "<td>" . $row["check_out_date"]. "</td>";
				echo "<td>" . $row["didPay"        ]. "</td>";
				echo "<td>" . "$".$row["total"     ]. "</td>";
				echo '</tr>';
			}
			
			echo '</tbody>';
			echo '</table>';
			echo "Note: A 0 in the 'Paid?' column indicates that the payment has not been made in full."."<br>";
			echo "A 1 indicates that the payment was made in full."."<br>"."<br>";				
	} 
	else {
    	echo "0 results";
	}
}
mysqli_close($conn);
?>

</html>