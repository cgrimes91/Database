<!DOCTYPE html>
<html>
<body>

<?php 
require('connection.php');
?>

<?php
$name  = $_POST["new_user_name"];
$user  = $_POST["new_phone_num"];
$pass  = $_POST["new_pass"     ];
$in_d  = $_POST["new_date_in"  ];
$out_d = $_POST["new_date_out" ];
$loca  = $_POST["new_local"    ];
$room  = $_POST["new_room_no"  ];
$size  = $_POST["party_size"   ];

// Check to make sure dates were entered
if($in_d == "" OR $out_d == ""){
	echo "The date(s) you provided are invalid, please try again.<br>";
}
// Check to make sure check out date is after check in date
elseif(!($in_d < $out_d)){
	echo "The check out date must be after the check in date.  Please try again.";
}
else{
	$in_d2  = $_POST["new_date_in"  ];
	$out_d2 = $_POST["new_date_out" ];
	$user2  = $_POST["new_phone_num"];

	// Removes dashes from in date
	$in_d = (string) $in_d;
	$in_d = str_replace("-", "", $in_d);

	// Removes dashes from out date
	$out_d = (string) $out_d;
	$out_d = str_replace("-", "", $out_d);

	// Removes dashes from phone number
	$user = (string) $user;
	$user = str_replace("-", "", $user);	

	//Check to make sure user entered a phone number
	if(empty($user)){
		echo "An error has occured. The phone number you entered is invalid. Please try another.<br><br>";
		echo "<p1>Return to New User Booking Page:</p1> <a href='new_user_book.php'>New User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	// Check to make sure user entered a branch
	if ($loca == ""){
		echo "An error has occured. The branch field may not be left empty.<br><br>";
		echo "<p1>Return to Returning User Booking Page:</p1> <a href='returning_user_book.php'>Returning User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	// Check to make sure user entered a room number
	if($room == ""){
		echo "An error has occured. The room number field may not be left empty.<br><br>";
		echo "<p1>Return to Returning User Booking Page:</p1> <a href='returning_user_book.php'>Returning User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	//Check to make sure user entered a password
	if(empty($pass)){
		echo "An error has occured. The password field may not be left empty. Please try again.<br><br>";
		echo "<p1>Return to New User Booking Page:</p1> <a href='new_user_book.php'>New User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	$conn -> autocommit(FALSE);

	// Check to see if phone number is already in use
	$sql = "SELECT * FROM guests WHERE phone_num = '$user'";
	$result = $conn->query($sql);
	
	if ($result->num_rows > 0){
		echo "An error has occured. The phone number you entered is already in use. Please try again.<br><br>";
		echo "<p1>Go to Returning User Booking Page:</p1> <a href='returning_user_book.php'>Returning User Booking</a><br>";
		echo "<p1>Return to New User Booking Page:</p1> <a href='new_user_book.php'>New User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	// Check to see if the user entered a valid location
	$sql = "select * from branch where branch_name = '$loca';";
	$result = $conn->query($sql);
	
	if ($result->num_rows == 0){
		echo "An error has occured. The location you entered is not valid. Please try again.<br><br>";
		echo "<p1>Return to New User Booking Page:</p1> <a href='new_user_book.php'>New User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	// Check to make sure user entered a valid room number
	$sql = "select * from rooms where branch_name = '$loca' and room_num = $room;";
	$result = $conn->query($sql);

	if ($result->num_rows<>1){
		echo "An error has occured. The room number you entered is not valid.<br><br>";
		echo "<p1>Return to New User Booking Page:</p1> <a href='new_user_book.php'>New User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	// Check to see if the requested booking overlaps with any current bookings
	$sql = "select*
		from bookings
		where 	branch_name = '$loca' AND
			room_num    =  $room  AND
			(
			(check_in_date <= $in_d  AND $in_d  <  check_out_date) OR 
			(check_in_date <  $out_d AND $out_d <= check_out_date) OR
			(check_in_date >  $in_d  AND $out_d >  check_out_date)
			);";

	$result = $conn->query($sql);
	
	if ($result->num_rows > 0){
		echo "An error has occured. The room you have selected is not available for the chosen dates.<br><br>";
		echo "<p1>Return to New User Booking Page:</p1> <a href='new_user_book.php'>New User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	// Adds new guest to the guest table
	$sql = "INSERT INTO guests (name, phone_num, password) VALUES ('$name', '$user', '$pass')";
	$result = $conn->query($sql);
	$conn -> commit();

	// Extra check to make sure that the new guest is only in the guest table exactly 1 time
	$sql = "SELECT * FROM guests where phone_num ='$user' AND password ='$pass'";
	$result = $conn->query($sql);

	if ($result->num_rows<>1){
		echo "An error has occured. The phone number you entered is already in use. Please try another.<br><br>";
		echo "<p1>Return to New User Booking Page:</p1> <a href='new_user_book.php'>New User Booking</a><br>";
		echo "<p1>Return to Date Selection:</p1> <a href='browse.php'>Date Selection</a><br>";
		exit(0);
	}

	echo "Hello user $user2<br>";

	// Inserts data to the bookings table
	$sql = "INSERT INTO bookings (phone_num, room_num, branch_name, party_size, check_in_date, check_out_date, didPay, didCheck_in, didCheck_out) VALUES ('$user', '$room', '$loca', '$size', '$in_d', '$out_d', 0, 0, 0)";
	
	if($conn->query($sql)){
		echo "Your reservation is for: $user2 on $in_d2 until $out_d2 at $loca in room number $room.";
	}
	else{
		echo "An error has occured. Please try again.";
	}
	$conn -> commit();

	// Check to make sure values were properly inserted	
	if (!$conn -> commit()) {
 		echo "Commit transaction failed";
	}
}
mysqli_close($conn);
?>

<br><br>
<p1>Return To Main Site:</p1>
<a href="index.html">Home</a><br>
<p1>Return to New User Booking Page:</p1> 
<a href='new_user_book.php'>New User Booking</a><br>

</body>
</html>