-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2020 at 03:44 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `phone_num` decimal(10,0) DEFAULT NULL,
  `room_num` decimal(3,0) NOT NULL,
  `branch_name` varchar(30) NOT NULL,
  `party_size` decimal(2,0) DEFAULT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date DEFAULT NULL,
  `didPay` decimal(1,0) DEFAULT NULL,
  `didCheck_in` decimal(1,0) DEFAULT NULL,
  `didCheck_out` decimal(1,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`phone_num`, `room_num`, `branch_name`, `party_size`, `check_in_date`, `check_out_date`, `didPay`, `didCheck_in`, `didCheck_out`) VALUES
('5555555555', '101', 'Cincinnati', '1', '2020-04-17', '2020-04-19', '0', '0', '0'),
('5555555555', '101', 'Cincinnati', '1', '2020-04-20', '2020-04-25', '0', '0', '0'),
('5555555555', '101', 'Cleveland', '1', '2020-04-15', '2020-04-19', '0', '0', '0'),
('5555555555', '101', 'Cleveland', '1', '2020-04-19', '2020-04-21', '0', '0', '0'),
('5555555555', '101', 'Kent', '1', '2020-04-17', '2020-04-19', '0', '0', '0'),
('5555555555', '101', 'Kent', '1', '2020-04-20', '2020-04-25', '0', '0', '0'),
('5555555555', '101', 'Kent', '1', '2020-04-25', '2020-04-27', '0', '0', '0'),
('5555555555', '102', 'Cincinnati', '1', '2020-04-17', '2020-04-19', '0', '0', '0'),
('5555555555', '102', 'Cleveland', '1', '2020-04-17', '2020-04-19', '0', '0', '0'),
('5555555555', '102', 'Kent', '1', '2020-04-14', '2020-05-14', '0', '0', '0'),
('5555555555', '103', 'Cleveland', '1', '2020-04-20', '2020-04-22', '0', '0', '0'),
('5555555555', '103', 'Cleveland', '1', '2020-04-22', '2020-04-25', '0', '0', '0'),
('5555555555', '103', 'Kent', '1', '2020-04-18', '2020-04-19', '0', '0', '0'),
('5555555555', '104', 'Cincinnati', '1', '2020-04-18', '2020-04-19', '0', '0', '0'),
('5555555555', '105', 'Cincinnati', '1', '2020-04-15', '2020-04-19', '0', '0', '0'),
('5555555555', '105', 'Cincinnati', '1', '2020-04-23', '2020-04-25', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_name` varchar(30) NOT NULL,
  `street_address` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `phone_num` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_name`, `street_address`, `city`, `state`, `phone_num`) VALUES
('Cincinnati', '4444 Main Street', 'Cincinnati', 'Ohio', '3305556666'),
('Cleveland', '1221 Euclid Avenue', 'Cleveland', 'Ohio', '3303334444'),
('Kent', '1234 Water Street', 'Kent', 'Ohio', '3301112222');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_name` varchar(30) NOT NULL,
  `branch_name` varchar(30) NOT NULL,
  `budget` decimal(9,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_name`, `branch_name`, `budget`) VALUES
('Finance', 'Cincinnati', '200000.00'),
('Finance', 'Cleveland', '400000.00'),
('Finance', 'Kent', '300000.00'),
('Front Desk', 'Cincinnati', '50000.00'),
('Front Desk', 'Cleveland', '200000.00'),
('Front Desk', 'Kent', '100000.00'),
('Housekeeping', 'Cincinnati', '75000.00'),
('Housekeeping', 'Cleveland', '100000.00'),
('Housekeeping', 'Kent', '100000.00');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `name` varchar(30) DEFAULT NULL,
  `phone_num` decimal(10,0) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `dept_name` varchar(30) DEFAULT NULL,
  `branch_name` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `salary` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`name`, `phone_num`, `password`, `dept_name`, `branch_name`, `email`, `salary`) VALUES
('Jim', '3301111111', 'Jim', 'Finance', 'Kent', 'jim@hotel.com', '50000.00'),
('John', '3302222222', 'John', 'Front Desk', 'Kent', 'john@hotel.com', '60000.00'),
('Nick', '3303333333', 'Nick', 'Housekeeping', 'Kent', 'nick@hotel.com', '50000.00'),
('Emily', '3304444444', 'Emily', 'Finance', 'Cleveland', 'emily@hotel.com', '55000.00'),
('Tim', '3305555555', 'Tim', 'Front Desk', 'Cleveland', 'tim@hotel.com', '35000.00'),
('Jane', '3306666666', 'Jane', 'Housekeeping', 'Cleveland', 'jane@hotel.com', '60000.00'),
('Dana', '3307777777', 'Dana', 'Finance', 'Cincinnati', 'dana@hotel.com', '45000.00'),
('Alex', '3308888888', 'Alex', 'Front Desk', 'Cincinnati', 'alex@hotel.com', '90000.00'),
('Fred', '3309999999', 'Fred', 'Housekeeping', 'Cincinnati', 'fred@hotel.com', '20000.00');

-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE `guests` (
  `name` varchar(30) DEFAULT NULL,
  `phone_num` decimal(10,0) NOT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `guests`
--

INSERT INTO `guests` (`name`, `phone_num`, `password`) VALUES
('Doug', '5555555555', 'Doug');

-- --------------------------------------------------------

--
-- Stand-in structure for view `guest_totals`
-- (See below for the actual view)
--
CREATE TABLE `guest_totals` (
`name` varchar(30)
,`phone_num` decimal(10,0)
,`branch_name` varchar(30)
,`room_num` decimal(3,0)
,`check_out_date` date
,`didPay` decimal(1,0)
,`total` decimal(12,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_num` decimal(3,0) NOT NULL,
  `branch_name` varchar(30) NOT NULL,
  `floor` decimal(1,0) DEFAULT NULL,
  `num_beds` decimal(1,0) DEFAULT NULL,
  `sq_ft` decimal(4,0) DEFAULT NULL,
  `price_p_night` decimal(6,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_num`, `branch_name`, `floor`, `num_beds`, `sq_ft`, `price_p_night`) VALUES
('101', 'Cincinnati', '1', '1', '325', '59.99'),
('101', 'Cleveland', '1', '1', '300', '54.95'),
('101', 'Kent', '1', '1', '325', '59.99'),
('102', 'Cincinnati', '1', '2', '350', '69.99'),
('102', 'Cleveland', '1', '2', '300', '79.99'),
('102', 'Kent', '2', '2', '300', '79.99'),
('103', 'Cincinnati', '2', '2', '375', '79.99'),
('103', 'Cleveland', '2', '2', '400', '89.99'),
('103', 'Kent', '3', '2', '400', '99.99'),
('104', 'Cincinnati', '3', '2', '400', '89.99'),
('104', 'Cleveland', '2', '3', '450', '99.99'),
('105', 'Cincinnati', '3', '3', '400', '109.99');

-- --------------------------------------------------------

--
-- Stand-in structure for view `rooms_available`
-- (See below for the actual view)
--
CREATE TABLE `rooms_available` (
`room_num` decimal(3,0)
,`branch_name` varchar(30)
,`floor` decimal(1,0)
,`num_beds` decimal(1,0)
,`sq_ft` decimal(4,0)
,`price_p_night` decimal(6,2)
,`phone_num` decimal(10,0)
,`party_size` decimal(2,0)
,`check_in_date` date
,`check_out_date` date
,`didPay` decimal(1,0)
,`didCheck_in` decimal(1,0)
,`didCheck_out` decimal(1,0)
);

-- --------------------------------------------------------

--
-- Structure for view `guest_totals`
--
DROP TABLE IF EXISTS `guest_totals`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `guest_totals`  AS  (select `guests`.`name` AS `name`,`guests`.`phone_num` AS `phone_num`,`bookings`.`branch_name` AS `branch_name`,`bookings`.`room_num` AS `room_num`,`bookings`.`check_out_date` AS `check_out_date`,`bookings`.`didPay` AS `didPay`,`rooms`.`price_p_night` * (to_days(`bookings`.`check_out_date`) - to_days(`bookings`.`check_in_date`)) AS `total` from ((`guests` join `bookings` on(`guests`.`phone_num` = `bookings`.`phone_num`)) join `rooms` on(`bookings`.`room_num` = `rooms`.`room_num` and `bookings`.`branch_name` = `rooms`.`branch_name`))) ;

-- --------------------------------------------------------

--
-- Structure for view `rooms_available`
--
DROP TABLE IF EXISTS `rooms_available`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `rooms_available`  AS  (select `rooms`.`room_num` AS `room_num`,`rooms`.`branch_name` AS `branch_name`,`rooms`.`floor` AS `floor`,`rooms`.`num_beds` AS `num_beds`,`rooms`.`sq_ft` AS `sq_ft`,`rooms`.`price_p_night` AS `price_p_night`,`bookings`.`phone_num` AS `phone_num`,`bookings`.`party_size` AS `party_size`,`bookings`.`check_in_date` AS `check_in_date`,`bookings`.`check_out_date` AS `check_out_date`,`bookings`.`didPay` AS `didPay`,`bookings`.`didCheck_in` AS `didCheck_in`,`bookings`.`didCheck_out` AS `didCheck_out` from (`rooms` join `bookings` on(`rooms`.`room_num` = `bookings`.`room_num` and `rooms`.`branch_name` = `bookings`.`branch_name`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`room_num`,`branch_name`,`check_in_date`),
  ADD KEY `phone_num` (`phone_num`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_name`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_name`,`branch_name`),
  ADD KEY `branch_name` (`branch_name`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`phone_num`),
  ADD KEY `dept_name` (`dept_name`,`branch_name`);

--
-- Indexes for table `guests`
--
ALTER TABLE `guests`
  ADD PRIMARY KEY (`phone_num`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_num`,`branch_name`),
  ADD KEY `branch_name` (`branch_name`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`room_num`,`branch_name`) REFERENCES `rooms` (`room_num`, `branch_name`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`phone_num`) REFERENCES `guests` (`phone_num`);

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `department_ibfk_1` FOREIGN KEY (`branch_name`) REFERENCES `branch` (`branch_name`) ON DELETE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`dept_name`,`branch_name`) REFERENCES `department` (`dept_name`, `branch_name`) ON DELETE SET NULL;

--
-- Constraints for table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `rooms_ibfk_1` FOREIGN KEY (`branch_name`) REFERENCES `branch` (`branch_name`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
