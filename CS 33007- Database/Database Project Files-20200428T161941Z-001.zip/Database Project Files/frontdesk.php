<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="index.css">
</head>

<?php 
require('connection.php');
?>

<?php

$phone_num = $_POST['username'];
$password = $_POST['password'];

if ($phone_num == "" OR $password == ""){
    echo "Please enter a username or password"."<br>";
}
else{
	// Removes dashes from phone number
	$phone_num = (string) $phone_num;
	$phone_num = str_replace("-", "", $phone_num);

	$sql = "select password from employee where dept_name = 'Front Desk' and phone_num = $phone_num;";

	$result = mysqli_query($conn, $sql);

	$returnVal = mysqli_fetch_assoc($result);

	if (!isset($returnVal['password'])){
		echo "Invalid username, password, or user is not a member of this branch"."<br>";
	}
	else if ($password != $returnVal['password']){
		echo "Invalid username and/or password"."<br>";
	}
	else{
		header('Location: frontdeskoption.html');
	}
}
mysqli_close($conn);
?>

<li><a class="error-button" href="front.html">Return to front desk login page</a></li>

</html>