<!DOCTYPE html>
<html>

<?php 
require('connection.php');
?>

<a class="button" href="frontdeskoption.html">Return to front desk options</a> <br>
<a class="button" href="bookings.php">View bookings</a> <br>
<a class="button" href="front.html">Return to front desk login</a> <br>

<h1>Guest payment page</h1>
<p1>Only fill out this form if the guest has paid in full!!</p1> <br> <br>

<?php
//Runs query to output list of all branches
echo "Please choose from the following branches:"."<br>";
$sql = "select branch_name from branch";
$results = mysqli_query($conn, $sql);

if (mysqli_num_rows($results) > 0){
	while($row = mysqli_fetch_assoc($results)){
		echo $row["branch_name"]."<br>";
	}
}
else{
	echo "No branches";
}
echo "<br>";
?>

<form method = "post">
	Room Number: <br>
	<input type = "number" name = "room"> <br> <br>

	Branch: <br>
	<input type = "text"   name = "branch"> <br> <br>

	Check in date: <br>
	<input type = "date"   name = "date"> <br> <br>

  	<input type = "submit"> <br> <br>
</form>

<?php

if(!isset($_POST['branch'])){
	die();
}

$room   = $_POST['room'  ];
$branch = $_POST['branch'];
$date   = $_POST['date'  ];

if ($branch == "" OR $date == "" OR $room == ""){
	echo "Please fill out all forms"."<br>";
}
else{
	// Removes dashes from date
	$date = (string) $date;
	$date = str_replace("-", "", $date);

	// Check to see if the room is booked
	$sql = "select *
		from bookings
		where room_num = $room AND branch_name = '$branch' AND check_in_date = $date;";

	$result = mysqli_query($conn, $sql);

	if ($result->num_rows <> 1){
		echo "There are no bookings for this room on this date.<br><br>";
	}
	else{
		// Check in the guest
		$sql = "update bookings
			set didPay = 1
			where room_num = $room AND branch_name = '$branch' AND check_in_date = $date;";

		$result = mysqli_query($conn, $sql);

		// Output result in table format
		echo "Guest payment entered!<br><br>";

		$select = "select name, phone_num, branch_name, room_num, check_in_date, check_out_date, party_size, price_p_night, didCheck_in, didCheck_out, didPay, datediff (check_out_date, check_in_date) as num_nights, price_p_night * (datediff (check_out_date, check_in_date)) as total ";

		$sql = 	"$select
			from guests natural join bookings natural join rooms
			where room_num = $room AND branch_name = '$branch' AND check_in_date = $date;";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			echo '<table border>';
			echo '<thead><tr>';
			echo '<th>'."Name".'</th>'.'<th>'."Phone Number".'</th>'.'<th>'."Branch Name".'</th>'.'<th>'."Room Num".'</th>'.'<th>'."Check in Date".'</th>'.'<th>'."Check out Date".'</th>'.'<th>'."Price per night".'</th>'.'<th>'."Num Nights".'</th>'.'<th>'."Total Due".'</th>'.'<th>'."Party Size".'</th>'.'<th>'."Check in?".'</th>'.'<th>'."Check out?".'</th>'.'<th>'."Paid?".'</th>';
			echo '</tr></thead>';
			echo '<tbody>';

			while($row = mysqli_fetch_assoc($result)) {
				echo '<tr>';
				echo "<td>" . $row["name"             ]. "</td>";
				echo "<td>" . $row["phone_num"        ]. "</td>";
				echo "<td>" . $row["branch_name"      ]. "</td>";
				echo "<td>" . $row["room_num"         ]. "</td>";
				echo "<td>" . $row["check_in_date"    ]. "</td>";
				echo "<td>" . $row["check_out_date"   ]. "</td>";			
				echo "<td>" . "$".$row["price_p_night"]. "</td>";
				echo "<td>" . $row["num_nights"       ]. "</td>";
				echo "<td>" . "$".$row["total"        ]. "</td>";
				echo "<td>" . $row["party_size"       ]. "</td>";
				echo "<td>" . $row["didCheck_in"      ]. "</td>";
				echo "<td>" . $row["didCheck_out"     ]. "</td>";
				echo "<td>" . $row["didPay"           ]. "</td>";
				echo '</tr>';
			}
		
			echo '</tbody>';
			echo '</table>';				
		}
		else{
			echo "Error";
		}
	}
}
mysqli_close($conn);
?>

</html>