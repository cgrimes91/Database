<!DOCTYPE html>
<html>
<body>

<h1>New user</h1>
<h1>Please Enter Your Information</h1>

<?php 
require('connection.php');
?>

<?php
//Runs query to output list of all branches
echo "Please choose from the following branches:"."<br>";
$sql = "select branch_name from branch";
$results = mysqli_query($conn, $sql);

if (mysqli_num_rows($results) > 0){
	while($row = mysqli_fetch_assoc($results)){
		echo $row["branch_name"]."<br>";
	}
}
else{
	echo "No branches";
}
echo "<br>";
mysqli_close($conn);
?>

<form action = "new_book.php" method = "post">
	User's Name:       <input type = "text"                name = "new_user_name"> <br>
	User Phone number: <input type = "tel"  id   = "phone" name = "new_phone_num" placeholder = "123-456-7890" pattern = "[0-9]{3}-[0-9]{3}-[0-9]{4}" required> <br>
	User Password:     <input type = "password"            name = "new_pass"     > Not Case Sensitive <br>
	Party Size:        <input type = "number"  min = "1"   name = "party_size"   > <br>
	Branch Name:       <input type = "text"                name = "new_local"    > <br>
	Room No:           <input type = "number"              name = "new_room_no"  > <br>
	Check in Date:     <input type = "date"                name = "new_date_in"  > <br>
	Check out Date:    <input type = "date"                name = "new_date_out" > <br>
                   	   <input type = "submit">
</form>

<br><br>
<p1>Return to Date Selection :</p1>
<a href="browse.php">Date Selection</a><br>

</body>
</html>