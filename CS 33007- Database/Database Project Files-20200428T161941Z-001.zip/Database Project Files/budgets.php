<!DOCTYPE html>
<html>

<?php 
require('connection.php');
?>

<a class="button" href="financeoption.html">Return to option selection</a> <br>
<a class="button" href="finance.html">Return to finance login</a> <br>
<a class="button" href="employee.html">Return to department selection</a> <br><br><br>

<h1>Please choose a branch to view department budgets</h1>

<?php
//Runs query to output list of all branches
echo "Please choose from the following branches:"."<br>";
$sql = "select branch_name from branch";
$results = mysqli_query($conn, $sql);

if (mysqli_num_rows($results) > 0){
	while($row = mysqli_fetch_assoc($results)){
		echo $row["branch_name"]."<br>";
	}
}
else{
	echo "No branches";
}
echo "<br>";
?>


<form method = "post">
	Branch: <br>
	<input type="text" name="branch"><br><br>
	<input type="submit"><br><br>
</form>

<?php

if(!isset($_POST['branch'])){
	die();
}

$branch = $_POST['branch'];

if ($branch == ""){
    echo "0 results"."<br>";
}
else{
	$message = "The budgets of each department at the $branch branch are:";
	echo "$message"."<br>"."<br>";

	$sql = "select dept_name, budget from department where branch_name = '$branch';";
	$result = mysqli_query($conn, $sql);

	//Outputs result of the query
	if (mysqli_num_rows($result) > 0) {
			echo '<table border>';
			echo '<thead><tr>';
			echo '<th>'."Department Name".'</th>'.'<th>'."Budget".'</th>';
			echo '</tr></thead>';
			echo '<tbody>';

			while($row = mysqli_fetch_assoc($result)) {
				echo '<tr>';
				echo "<td>" . $row["dept_name"]. "</td>";
				echo "<td>" . "$".$row["budget"]. "</td>";
				echo '</tr>';
			}
			
			echo '</tbody>';
			echo '</table>';				
	} 
	else {
    	echo "0 results";
	}
}
mysqli_close($conn);
?>

</html>